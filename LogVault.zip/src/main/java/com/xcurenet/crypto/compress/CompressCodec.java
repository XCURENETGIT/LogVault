package com.xcurenet.crypto.compress;

public interface CompressCodec {
}
