package com.xcurenet.logvault.exception;

public class AlertException extends Exception {

	private static final long serialVersionUID = -5714776608145039680L;

	public AlertException(final Throwable cause) {
		super(cause);
	}
}
