package com.xcurenet.logvault.exception;

public class DBWriteException extends Exception {

	private static final long serialVersionUID = -5714776608145039680L;

	public DBWriteException(final Throwable cause) {
		super(cause);
	}
}
