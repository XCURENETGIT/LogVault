package com.xcurenet.logvault.exception;

public class IndexerException extends Exception {

	public IndexerException(final Throwable cause) {
		super(cause);
	}
}
