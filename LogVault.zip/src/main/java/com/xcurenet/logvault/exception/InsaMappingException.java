package com.xcurenet.logvault.exception;

public class InsaMappingException extends Exception {

	private static final long serialVersionUID = -5714776608145039680L;

	public InsaMappingException(final Throwable cause) {
		super(cause);
	}
}
