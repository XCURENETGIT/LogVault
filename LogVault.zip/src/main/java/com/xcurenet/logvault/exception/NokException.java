package com.xcurenet.logvault.exception;

public class NokException extends Exception {
	private static final long serialVersionUID = 3944949145895375765L;

	public NokException(final String message) {
		super(message);
	}
}
