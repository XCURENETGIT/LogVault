package com.xcurenet.logvault.exception;

public class ParsingException extends Exception {

	private static final long serialVersionUID = -5714776608145039680L;

	public ParsingException(final Throwable cause) {
		super(cause);
	}
}
