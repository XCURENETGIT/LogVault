package com.xcurenet.logvault.exception;

public class SkipFileException extends Exception {
	private static final long serialVersionUID = -5748372569079732077L;

	public SkipFileException(final String message) {
		super(message);
	}
}
