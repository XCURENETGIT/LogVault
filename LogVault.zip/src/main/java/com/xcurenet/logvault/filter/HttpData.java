package com.xcurenet.logvault.filter;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@Data
public class HttpData {

	public enum METHOD {
		GET, POST, PUT;

		public static METHOD fromString(final String methodName) {
			for (final METHOD method : METHOD.values()) {
				if (method.name().equalsIgnoreCase(methodName)) {
					return method;
				}
			}
			return null;
		}
	}

	private String host;
	private String uri;
	protected METHOD method;
	protected long contentLength;
	protected String userAgent;
	protected List<String> userAgentFilter = new ArrayList<>();
	protected boolean useNoLogURL;
	protected boolean useFilter;

	public void setHost(final String host) {
		this.host = StringUtils.isNotEmpty(host) ? host.trim().toLowerCase() : null;
	}

	public void setUri(final METHOD method, final String uri) {
		this.method = method;
		this.uri = getUri(uri.split(" ", 2)[0]);
	}

	private static String getUri(final String str) {
		try {
			final URL url = new URL(str);
			return url.getFile();
		} catch (final MalformedURLException e) {
			return str;
		}
	}
}