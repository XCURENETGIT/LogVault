package com.xcurenet.logvault.filter;

import com.xcurenet.common.utils.CommonUtil;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Log4j2
@ToString
public class HttpXml {
	@Getter
	private final String filename;
	private final List<Pattern> listHosts = new ArrayList<Pattern>();
	private final List<Pattern> listUrls = new ArrayList<Pattern>();
	private final Set<String> listSiteAttrs = new HashSet<String>();
	private static final String BODY_URLS = "body_urls";
	private static final String ENCODE_URLS = "encode_urls";
	private static final String ATTACH_URLS = "attach_urls";
	private static final String MIDINFO_URLS = "midinfo_urls";

	private boolean isIgnoreSize = false;

	private enum RootElementType {
		SITEXML, HTTPDATA
	}

	public HttpXml(String filename) {
		this.filename = filename;
	}

	public boolean isLoaded() {
		return !listHosts.isEmpty() && !listUrls.isEmpty();
	}

	public void loadXML(final InputStream in) throws Exception {
		final SAXBuilder builder = new SAXBuilder();
		final Document doc = builder.build(in);
		final Element rootElement = doc.getRootElement();
		if (rootElement == null) {
			return;
		}

		final Element hosts = rootElement.getChild("hosts");
		if (hosts == null) {
			return;
		}

		for (final Element e : hosts.getChildren()) {
			final String host = e.getValue().trim();
			if (StringUtils.isNotEmpty(host)) {
				listHosts.add(Pattern.compile("^" + host + "$", Pattern.CASE_INSENSITIVE));
				log.debug("Host added: {}", host);
			}
		}

		// autosave_urls 이 비로깅에서 로깅URL로 정책 변경
		addUrl(rootElement.getChild("autosave_urls"));

		final RootElementType rootElementType = CommonUtil.getEnum(RootElementType.class, rootElement.getName().toUpperCase());
		if (rootElementType == null) {
			throw new Exception("Invalid XML File.");
		}

		// XML 파일의 루트 요소 이름에 따라 구분한다.
		switch (rootElementType) {
			case HTTPDATA:
				final Element requestdata = rootElement.getChild("requestdata");
				addUrl(requestdata.getChild(BODY_URLS));
				addUrl(requestdata.getChild(ENCODE_URLS));
				addUrl(requestdata.getChild(ATTACH_URLS));

				final Element responsedata = rootElement.getChild("responsedata");
				addUrl(responsedata.getChild(BODY_URLS));
				addUrl(responsedata.getChild(ATTACH_URLS));
				break;
			case SITEXML:
				// Decoder 7.3.0 이후
				final Element send = rootElement.getChild("send");
				addUrl(send.getChild(BODY_URLS));
				addUrl(send.getChild(MIDINFO_URLS));
				addUrl(send.getChild(ATTACH_URLS));

				final Element receive = rootElement.getChild("receive");
				addUrl(receive.getChild(BODY_URLS));
				addUrl(receive.getChild(MIDINFO_URLS));
				addUrl(receive.getChild(ATTACH_URLS));
				break;
			default:
				break;
		}

		// siteattr에 NOWMU 값이 존재하면 사이즈 무시 후, WMU 생성하지 않도록 설정
		addSiteAttr(rootElement.getChild("siteattr"));
	}

	private void addUrl(final Element element) {
		if (element == null) {
			return;
		}
		for (final Element e : element.getChildren()) {
			final String url = e.getValue().trim();
			if (StringUtils.isNotEmpty(url)) {
				listUrls.add(Pattern.compile(url, Pattern.CASE_INSENSITIVE));
				log.debug("URL added: {}", url);
			}
		}
	}

	private void addSiteAttr(final Element element) {
		if (element == null) {
			return;
		}
		final String[] attrs = element.getValue().split(",");
		for (final String attr : attrs) {
			listSiteAttrs.add(attr);
			log.debug("Site_Attrs added: {}", attr);
		}
	}

	public boolean checkSiteAttr(final String attr) {
		return listSiteAttrs.contains(attr);
	}

	public boolean checkHost(final String host) {
		for (final Pattern pattern : listHosts) {
			final Matcher matcher = pattern.matcher(host);
			if (matcher.find()) {
				return true;
			}
		}
		return false;
	}

	public boolean checkLoggingURL(final String path) {
		for (final Pattern url : listUrls) {
			final Matcher matcher = url.matcher(path);
			if (matcher.find()) {
				return true;
			}
		}
		return false;
	}

	public void setIgnoreSize(final boolean b) {
		this.isIgnoreSize = b;
	}

	public boolean isIgnoreSize() {
		return this.isIgnoreSize;
	}
}