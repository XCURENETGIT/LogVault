package com.xcurenet.logvault.filter;

import com.xcurenet.common.utils.PropConfig;
import io.minio.GetObjectArgs;
import io.minio.ListObjectsArgs;
import io.minio.MinioClient;
import io.minio.Result;
import io.minio.messages.Item;
import lombok.Data;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Data
@Log4j2
public class HttpXmls {
	private static String HTTP_XML_PATH = "info/http_xml";
	private static boolean exist = true;
	private static long fileTime;

	private List<HttpXml> httpXmls = new ArrayList<>();

	public HttpXmls(final PropConfig props) {
		final List<HttpXml> httpXmls = loadHttpXML(props);
		if (httpXmls != null) {
			this.httpXmls = httpXmls;
		}
	}

	private List<HttpXml> loadHttpXML(final PropConfig props) {
		String clusterNodes = props.getProperty("minio.clusterNodes");
		String bucketName = props.getProperty("minio.bucketName");
		String accessKey = props.getProperty("minio.accessKey");
		String secretKey = props.getProperty("minio.secretKey");

		try {
			MinioClient minioClient = MinioClient.builder().endpoint(clusterNodes).credentials(accessKey, secretKey).build();

			final ArrayList<HttpXml> list = new ArrayList<>();
			final Iterable<Result<Item>> results = minioClient.listObjects(ListObjectsArgs.builder().bucket(bucketName).prefix(HTTP_XML_PATH).recursive(true).build());

			if (results == null) {
				// XML 파일이 존재하지 않는다.
				log.info("HTTP_XML is Not Exist");
				exist = false;
				return null;
			}

			for (Result<Item> result : results) {
				InputStream in = null;
				try {
					final String fileName = result.get().objectName();
					in = minioClient.getObject(GetObjectArgs.builder().bucket(bucketName).object(HTTP_XML_PATH + "/" + fileName).build());
					final HttpXml filter = loadHttpFilter(in, fileName);
					if (filter != null) {
						list.add(filter);
						log.info("HTTP_XML file added: {}", filter);
					}
				} catch (final Exception e) {
					log.error(e.getMessage(), e);
				} finally {
					IOUtils.closeQuietly(in);
				}
			}
			log.info("HTTP_XML Load Complete");
			return list;
		} catch (final Exception e) {
			log.warn(e.getMessage(), e);
			return null;
		}
	}

	private HttpXml loadHttpFilter(final InputStream in, final String name) throws Exception {
		log.info("LOAD HTTP_XML FILE: {}", name);
		final HttpXml filter = new HttpXml(name);
		filter.loadXML(in);
		if (name.equals("mysingle.xml") || name.equals("newmysingle.xml") || filter.checkSiteAttr("NOWMU")) {
			filter.setIgnoreSize(true);
		}
		return filter.isLoaded() ? filter : null;
	}

	public HttpXml getHttpXml(final String host) {
		if (!exist) {
			log.error("HTTP_XML list does not exists. Please check the '{}' path.", HTTP_XML_PATH);
			System.exit(1);
		}
		for (final HttpXml httpXml : httpXmls) {
			if (httpXml.checkHost(host)) {
				return httpXml;
			}
		}
		log.debug("HTTP_XML not found by host {}", host);
		return null;
	}
}
