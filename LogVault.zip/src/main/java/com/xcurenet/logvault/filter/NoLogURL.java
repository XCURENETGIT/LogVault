package com.xcurenet.logvault.filter;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.xcurenet.common.utils.FastWildcardMatchValue;
import com.xcurenet.common.utils.FastWildcardMatchValue.MatchInterface;
import com.xcurenet.common.utils.PropConfig;
import io.minio.DownloadObjectArgs;
import io.minio.MinioClient;
import io.minio.StatObjectArgs;
import io.minio.StatObjectResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class NoLogURL {
	private static final Logger LOG = LoggerFactory.getLogger(NoLogURL.class);
	private static final String DEFAULT_FILENAME = "conf/nologurl.conf";
	private static final String CUSTOM_FILENAME = "/info/nolog_url.json";
	private FastWildcardMatchValue<NoLogURLItem> noLogUrls = new FastWildcardMatchValue<>(true);
	private long filetime;
	private boolean init;

	/**
	 * NoLogURL 필터의 설정 정보 객체를 생성하고, 초기화한다.<br>
	 * URL 관련 정보를 담은 맵을 준비하고, 맵을 기반으로 NoLogUrls를 로드한다.<br>
	 * - Map<String, NoLogURLItem> map: URL 관련 정보를 담을 맵 자료구조 (key=URL, value=URL에 대한
	 * NoLogURLItem 객체)
	 */
	public NoLogURL(final PropConfig props) {
		try {
			final Map<String, NoLogURLItem> map = new HashMap<>();
			if ((copyNoLogURLFile(props) && appendNoLogURL(map)) || !init) {
				init = true;
				load(map);
			}
		} catch (final IOException e) {
			LOG.error(e.getMessage(), e);
		}
	}

	/**
	 * NoLogUrls를 로드한다.<br>
	 * 1. 설정 파일에서 URL 문자열을 추출하여 맵에 담는다.<br>
	 * 2. URL을 패턴으로, NoLogURLItem 객체를 값으로 하여 FastWildcardMatchValue에 패턴을 추가한다.
	 *
	 * @param map URL 관련 정보를 담을 맵 자료구조 (key=URL, value=URL에 대한 NoLogURLItem 객체)
	 * @throws IOException 처리 중에 발생한 입출력 예외
	 */
	private void load(final Map<String, NoLogURLItem> map) throws IOException {
		if (map != null) {
			loadNoLogURL(map); // URL 주소 map에 저장
			final FastWildcardMatchValue<NoLogURLItem> nolog = new FastWildcardMatchValue<>(true);
			int count = 0;
			for (final Entry<String, NoLogURLItem> entry : map.entrySet()) {
				nolog.addPattern(entry.getKey(), entry.getValue());
				count++;
			}
			this.noLogUrls = nolog;
			LOG.info("{} NoLogUrls loaded.", count);
		}
	}

	/**
	 * 로컬에 있는 nolog_url.json에 기재된 URL 목록을 맵에 추가한다.
	 *
	 * @param map URL 관련 정보를 담을 맵 자료구조 (key=URL, value=URL에 대한 NoLogURLItem 객체)
	 * @return 처리 성공 여부
	 * @throws IOException URL 추가 중에 발생한 입출력 예외
	 */
	private boolean appendNoLogURL(final Map<String, NoLogURLItem> map) throws IOException {
		try {
			final File file = new File(CUSTOM_FILENAME);
			if (!file.exists()) {
				return false;
			}
			final JSONArray jsonArray = JSONArray.from(new FileInputStream(file));
			for (final Object object : jsonArray) {
				final JSONObject obj = (JSONObject) object;
				final String url = (String) obj.get("URL");
				addURL(map, url);
			}
		} catch (final FileNotFoundException e) {
			LOG.error(e.getMessage(), e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return true;
	}


	/**
	 * Minio 파일시스템의 nolog_url.json 파일을 로컬로 복사한다.<br>
	 * 실행 조건: nolog_url.json이 하둡 파일시스템 내 지정된 경로에 존재하고, 이전 설정 파일이 적용된 후 수정되었을 때<br>
	 * - NOLOGURL_JSON(Minio 파일시스템 경로): /decoder/info/nolog_url.json<br>
	 * - LOCAL_NOLOGURL_JSON(로컬 경로): conf/nolog_url.json
	 *
	 * @return 처리 성공 여부
	 */
	private boolean copyNoLogURLFile(final PropConfig props) {
		String clusterNodes = props.getProperty("minio.clusterNodes");
		String bucketName = props.getProperty("minio.bucketName");
		String accessKey = props.getProperty("minio.accessKey");
		String secretKey = props.getProperty("minio.secretKey");
		try (MinioClient minioClient = MinioClient.builder().endpoint(clusterNodes).credentials(accessKey, secretKey).build()) {
			final StatObjectResponse response = minioClient.statObject(StatObjectArgs.builder().bucket(bucketName).object(CUSTOM_FILENAME).build());
			if (response != null && response.lastModified().toInstant().toEpochMilli() != filetime) {
				filetime = response.lastModified().toInstant().toEpochMilli();
				minioClient.downloadObject(DownloadObjectArgs.builder().bucket(bucketName).object(CUSTOM_FILENAME).filename(CUSTOM_FILENAME).overwrite(true).build());
				return true;
			}
		} catch (final Exception e) {
			LOG.warn(e.getMessage(), e);
		}
		return false;
	}

	/**
	 * 설정 파일에서 URL 문자열을 추출하여 맵에 담는다.<br>
	 * 지정한 설정 파일이 존재하지 않으면 아무 처리도 하지 않는다.
	 *
	 * @param map URL 관련 정보를 담을 맵 자료구조 (key=URL, value=URL에 대한 NoLogURLItem 객체)
	 * @throws IOException 실행 중에 발생한 입출력 예외
	 */
	private void loadNoLogURL(final Map<String, NoLogURLItem> map) throws IOException {
		final File file = new File(NoLogURL.DEFAULT_FILENAME);
		if (!file.exists()) {
			return;
		}

		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String line;
			while ((line = reader.readLine()) != null) {
				line = line.trim();
				if (line.isEmpty()) {
					continue;
				}
				final String[] split = line.split("\\|", 2);
				final String url = split[0].trim().toLowerCase(); // URL 주소만 가져오기
				addURL(map, url);
			}
		} finally {
			assert reader != null;
			reader.close();
		}
	}

	/**
	 * URL 문자열의 호스트, 포트 번호, URI 정보를 분석하여 맵에 담는다.<br>
	 * 포트 번호가 -1, 80, 443(SSL)일 때는 호스트에 포함하지 않는다.
	 *
	 * @param map    URL 관련 정보를 담을 맵 자료구조 (key=URL, value=URL에 대한 NoLogURLItem 객체)
	 * @param strUrl 분석할 URL 문자열
	 */
	private void addURL(final Map<String, NoLogURLItem> map, final String strUrl) {
		final SimpleURL url = new SimpleURL(strUrl);
		String host = url.getHost().toLowerCase();
		if (StringUtils.isEmpty(host)) {
			return;
		}

		final int port = url.getPort();
		// 443 port: SSL
		if (port != -1 && port != 80 && port != 443) {
			host += ":" + url.getPort();
		}

		NoLogURLItem item = map.get(host);
		if (item == null) {
			item = new NoLogURLItem(host);
			map.put(host, item);
		}

		if (!item.hostOnly) {
			final String uri = url.getFile();
			if (StringUtils.isEmpty(uri)) {
				item.hostOnly = true;
			} else {
				item.add(uri);
			}
		}
	}

	public static class NoLogURLItem {
		public String host;
		public boolean hostOnly;
		public Set<String> uris = new HashSet<>();

		public NoLogURLItem(final String host) {
			this.host = host;
		}

		public void add(final String uri) {
			uris.add(uri.toLowerCase());
		}
	}

	public static class NoLogURLMatch implements MatchInterface<NoLogURLItem> {
		private final String uri;

		public NoLogURLMatch(final String uri) {
			this.uri = uri.toLowerCase();
		}

		public boolean match(final NoLogURLItem item) {
			if (item.hostOnly) {
				return true;
			}
			for (final String noLogUrl : item.uris) {
				if (uri.startsWith(noLogUrl)) {
					return true;
				}
			}
			return false;
		}
	}

	public NoLogURLItem match(final String host, final String uri) {
		return noLogUrls.match(host, new NoLogURLMatch(uri));
	}
}
