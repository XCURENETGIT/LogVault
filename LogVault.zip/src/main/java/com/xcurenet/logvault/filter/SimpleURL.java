package com.xcurenet.logvault.filter;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * SimpleURL 클래스: URL, 호스트명, 포트 번호, 쿼리문 등의 정보를 담은 VO 클래스<br>
 * URL 문자열을 분석하고 정보를 저장한다.
 * 
 * @version 1.4.4
 * @since 2019년 1월 18일
 * @author 김정경
 * 
 */
public class SimpleURL {
    /**
     * URL 문자열<br>
     * - 구조: HOST:PORT/PATH?QUERY
     */
    private final String url;
    /**
     * URL 문자열 중 호스트명
     */
    private String host;
    /**
     * URL 문자열 중 포트 번호
     */
    private int port = -1;
    /**
     * URL 문자열 중 경로
     */
    private String path;
    /**
     * URL 문자열 중 쿼리문
     */
    private String query;
    /**
     * URL 문자열 중 경로와 쿼리문
     */
    private String file;

    /**
     * 입력받은 URL 문자열을 분석하여 SimpleURL 객체를 생성한다.
     * 
     * @param url URL 문자열
     * 
     * @version 1.4.4
     * @since 2019년 1월 18일
     * @author 김정경
     * 
     */
    public SimpleURL(final String url) {
        this.url = url.trim();
        parse(this.url);
    }

    /**
     * URL 문자열을 분석하고 정보를 저장한다.
     * 
     * @param url 분석할 URL 문자열
     * 
     * @version 1.4.4
     * @since 2019년 1월 18일
     * @author 김정경
     * 
     */
    private void parse(String url) {
        // URL 문자열에서 'http://' 또는 'https://'를 제거한다.
        if (url.length() >= 8) {
            final String prefix = url.substring(0, 8).toLowerCase();
            if (prefix.startsWith("http://")) {
                url = url.substring(7, url.length());               // URL
            } else if (prefix.startsWith("https://")) {
                url = url.substring(8, url.length());
            }
        }

        // URL 구조를 분석한다: 'HOST:PORT/PATH?QUERY'
        final String[] hostpath = url.split("/", 2);
        final String[] hostport = hostpath[0].split(":", 2);
        this.host = hostport[0];                                    // HOST
        if (hostport.length > 1) {
            final String strPort = hostport[1].trim();
            if (strPort.length() > 0) {
                try {
                    this.port = Integer.parseInt(strPort);          // PORT
                } catch (final NumberFormatException e) {
                }
            }
        }

        if (hostpath.length > 1 && hostpath[1].length() > 0) {
            this.file = "/" + hostpath[1].trim();                   // FILE = 'PATH?QUERY'
            final String[] pathquery = this.file.split("\\?", 2);
            this.path = pathquery[0];                               // PATH
            if (pathquery.length > 1) {
                this.query = pathquery[1];                          // QUERY
            }
        }
    }

    /**
     * 호스트명을 반환한다.
     * 
     * @return 호스트명
     * 
     * @version 1.4.4
     * @since 2019년 1월 18일
     * @author 김정경
     * 
     */
    public String getHost() {
        return StringUtils.isNotEmpty(host) ? host.trim() : host;
    }

    /**
     * 포트 번호를 반환한다.
     * 
     * @return 포트 번호
     * 
     * @version 1.4.4
     * @since 2019년 1월 18일
     * @author 김정경
     * 
     */
    public int getPort() {
        return port;
    }

    /**
     * 경로를 반환한다.
     * 
     * @return 경로
     * 
     * @version 1.4.4
     * @since 2019년 1월 18일
     * @author 김정경
     * 
     */
    public String getPath() {
        return StringUtils.isNotEmpty(path) ? path.trim() : path;
    }

    /**
     * 쿼리문을 반환한다.
     * 
     * @return 쿼리문
     * 
     * @version 1.4.4
     * @since 2019년 1월 18일
     * @author 김정경
     * 
     */
    public String getQuery() {
        return StringUtils.isNotEmpty(query) ? query.trim() : query;
    }

    /**
     * 파일명을 반환한다.
     * 
     * @return 파일명
     * 
     * @version 1.4.4
     * @since 2019년 1월 18일
     * @author 김정경
     * 
     */
    public String getFile() {
        return StringUtils.isNotEmpty(file) ? file.trim() : file;
    }

    /**
     * URL 문자열을 반환한다.
     * 
     * @return URL 문자열
     * 
     * @version 1.4.4
     * @since 2019년 1월 18일
     * @author 김정경
     * 
     * @see Object#toString()
     */
    @Override
    public String toString() {
        return StringUtils.isNotEmpty(url) ? url.trim() : url;
    }
}
